---
name: RamonoPro stack & secrets
description: Stack technique, secrets disponibles, buckets Supabase, template PDFMonkey, contraintes DB.
---

## Stack
TanStack Start + React 19 + Vite 7 + Bun + Supabase + Tailwind CSS 4 + Shadcn UI + Framer Motion. Port dev: 5000.

## Supabase
- URL: https://esdeyidgtbfandpxtqpr.supabase.co (hardcodée dans client.ts)
- Secrets: SUPABASE_SERVICE_ROLE_KEY (service role), PDFMONKEY_API_KEY
- Buckets créés (publics): `proofs`, `certificates`, `photos`, `logos`
- Tables: profiles, clients, interventions, certificates, invoices, reminders, subscriptions

## Profils (colonnes existantes)
id, email, full_name, company_name, phone, siret, address, default_price, legal_mentions

**Why:** Pas de DDL possible via REST API (pg-meta retourne 404, service role ≠ mot de passe DB). Nouvelles préférences UI (color, logo_url, website) stockées en localStorage avec clé `ramono-{feature}-{uid}`.

## PDFMonkey
- Template ID: 7acfd5fe-9db9-43ff-a35c-cb2cd93b5a58
- Variables template: cert_number, intervention_date, client_name, client_address, client_phone, installation_type, conduit_state, cleaning_done, vacuity_test, recommendations, technician_name, company_name, company_siret, company_phone, company_address, company_email, legal_mentions, has_signature, signature

## Architecture navigation
- `/dashboard` - 4 stats: certifs ce mois, clients actifs, à relancer, rappels
- `/documents` - Historique certificats avec numérotation CERT-YYYY-NNNN
- `/interventions` - Liste + envoi email
- `/interventions/new` - Formulaire 2 étapes: form → signature → génération
- `/invoices` - Statuts Payée/En attente/En retard (couleurs vert/orange/rouge)
- `/clients` - Liste + sheet détail (historique + certificats)
- `/reminders` - Relances avec bouton "Contacté" + appel téléphonique
- `/settings` - Infos entreprise + logo upload + couleur principale

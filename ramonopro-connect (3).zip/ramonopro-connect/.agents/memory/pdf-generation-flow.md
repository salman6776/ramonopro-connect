---
name: PDF generation flow
description: Flow complet de génération de certificat PDF — PDFMonkey + Supabase Storage.
---

## Flow (server function pdf.functions.ts)
1. Fetch profile user depuis Supabase REST (pour infos entreprise)
2. Compter certificats existants pour numéro séquentiel CERT-YYYY-NNNN
3. POST PDFMonkey /documents avec payload complet (y compris signature base64 si présente)
4. Poll statut toutes 2s, max 30s
5. GET download_url → télécharger bytes côté serveur
6. POST Supabase Storage /certificates/{user_id}/{intervention_id}.pdf (upsert)
7. Retourner { url: URL permanente publique, pdfBase64: string, certNumber: string }

## Signature électronique
- Canvas pad dans SignaturePad component (touch + mouse, no lib externe)
- Étape séparée dans new.tsx (step: 'form' | 'signature')
- Passée comme `signature_base64` (data URL base64 PNG)
- Incluse dans payload PDFMonkey comme variable `signature`

**Why:** Le PDF signé est la version officielle. Signature jamais stockée séparément (embarquée dans PDF).

## Numérotation certificats
- Comptage via Supabase REST avec header content-range
- Format: CERT-{year}-{String(n+1).padStart(4,'0')}
- Calculé server-side pour cohérence, retourné au client

## Contrainte importante
Impossible d'exécuter du DDL via le service role Supabase (pg-meta 404, pas d'accès direct Postgres). Toute nouvelle colonne nécessite le dashboard Supabase ou la CLI avec PAT.

---
name: DocRaptor / Prince XML CSS limitations
description: CSS properties that break layout in DocRaptor PDF generation (Prince XML engine)
---

## Rule
**Never use `display: flex`, `display: grid`, or `display: table-cell` on `<div>` elements in DocRaptor HTML templates.** Prince XML ignores these and layout collapses into a single column.

**Why:** DocRaptor uses Prince XML which has a different CSS engine than browsers. It does NOT support modern layout modules.

**How to apply:** Use ONLY real `<table>`, `<tr>`, `<td>` HTML elements for ALL multi-column layouts. Use inline styles. Simple box-model CSS (border, padding, margin, color, font-size, background) works fine.

## What works in Prince XML
- `<table>` layout (real HTML tables)
- `border`, `padding`, `margin`, `color`, `font-size`, `font-weight`
- `background-color`, `background`
- `border-radius` (modern Prince)
- `position: fixed` (for watermarks)
- `@page { size: A4; margin: ... }` — YES
- `text-align`, `vertical-align` on `<td>`
- `width` percentages on `<td>`
- `border-top`, `border-left`, etc.

## What does NOT work
- `display: flex` — ignored
- `display: grid` — ignored
- `display: table-cell` on `<div>` — unreliable
- `float` — unreliable
- Modern CSS selectors may not apply correctly

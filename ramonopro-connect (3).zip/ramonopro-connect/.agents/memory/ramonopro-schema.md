---
name: RamonoPro real Supabase schema
description: Correct column names for all tables — wrong names cause 400 PGRST204 errors
---

## Rule
Always use these exact column names. The old code had wrong names causing 400 errors.

## clients
- `full_name` (NOT `name`)
- `user_id`, `phone`, `email`, `address`, `created_at`

## interventions
- `photos_urls` (NOT `photos`)
- NO `recommendations` column — use `notes` instead
- `vacuity_test`, `notes`, `status`, `created_at`, `intervention_date`

## certificates
- NO `user_id` column — filter via interventions join
- NO `created_at` — use `generated_at`
- `intervention_id`, `pdf_url`, `generated_at`

## reminders
- `scheduled_date` (NOT `reminder_date`)
- status default: `"scheduled"` (NOT `"programmé"`)
- `intervention_id`, `client_id`, `sent_at`

## invoices
- NO `invoice_number` column
- NO `user_id` column  
- `issued_at` (NOT `created_at`)
- status default: `"pending"` (NOT `"en attente"`)
- `intervention_id`, `amount`, `status`, `pdf_url`, `due_date`

## Storage buckets
- `certificates` (public), `photos` (public), `logos` (public)

## fetchCertificates
Must join via interventions to filter by user: `.eq("interventions.user_id", userId)`
